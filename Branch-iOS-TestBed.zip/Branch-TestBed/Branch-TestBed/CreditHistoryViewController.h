//
//  CreditHistoryViewController.h
//  Branch-TestBed
//
//  Created by Qinwei Gong on 10/9/14.
//  Copyright (c) 2014 Branch Metrics. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CreditHistoryViewController : UITableViewController

@property (nonatomic, strong) NSArray *creditTransactions;

@end
